Read Below

This flask app has both Postgressql and Mysql endpoints as required. A Template is used for taking input.

To run them first open python in command prompt, then do the following - 

from main import db
db.create_all()

then run  main.py
after that-

URL FOR EACH DATABASE ONCE RUN-

1. URL FOR POSTGRESSQL - http://127.0.0.1:5000/PostgreSQL

2. URL FOR MYSQL - http://127.0.0.1:5000/MySQL




